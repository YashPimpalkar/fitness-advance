import './App.css';
import { Outlet} from 'react-router-dom'
import Box from '@mui/material/Box';
import { Suspense } from 'react';
import Footer from './components/Footer';
import Pricing from './components/Pricing';
import HeroBanner from './components/HeroBanner';




function App() {


  return (
    <div className="App">
      <Outlet />
      <Box width="400px"  sx={{ width: { xl: '1488px' } }} m="auto">
        <Suspense fallback={<div>Loading...</div>}>
        </Suspense>
        <Footer />
      </Box >
    </div>
  );
}

export default App;
